// index.js
import React from "react";
import ReactDOM from "react-dom";
import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import App from "./App";

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);

document.addEventListener("DOMContentLoaded", function () {
  console.log("Welcome to the Documentary World!");
});

root.render(
  <StrictMode>
    <App />
  </StrictMode>
);
